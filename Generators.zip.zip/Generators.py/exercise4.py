# Generator to yield unique words from a list
def unique_word_generator(word_list):
    seen = set()
    for word in word_list:
        word_lower = word.lower()
        if word_lower not in seen:
            seen.add(word_lower)
            yield word

# Test list
words = ["The", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog"]

# Test: Generate unique words
for unique in unique_word_generator(words):
    print(unique)
