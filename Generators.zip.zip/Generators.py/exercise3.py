# Generator to yield words from a string
def word_generator(text):
    for word in text.split():
        yield word

# Test string
sentence = "The quick brown fox jumps over the lazy dog."

# Test: Generate words
for word in word_generator(sentence):
    print(word)
