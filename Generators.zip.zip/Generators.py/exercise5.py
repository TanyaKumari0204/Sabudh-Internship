# Generator to yield sublists of length n
def sublist_generator(lst, n):
    for i in range(len(lst) - n + 1):
        yield lst[i:i+n]

# Test list
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Test: Generate sublists of length 3
for sublist in sublist_generator(numbers, 3):
    print(sublist)
