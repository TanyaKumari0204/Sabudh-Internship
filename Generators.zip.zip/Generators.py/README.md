# Python Assignment: Generators

## Overview
This assignment explores Python generators, which allow efficient iteration without storing entire sequences in memory.

## Tasks Summary

### 1. Fibonacci Generator
- **Approach**: Used a loop to yield Fibonacci numbers.
- **Challenge**: Managing initial values and updating them correctly.

### 2. Prime Number Generator
- **Approach**: Used a helper function to check primality.
- **Challenge**: Optimizing prime checks for performance.

### 3. Word Generator from String
- **Approach**: Split string and yield each word.
- **Challenge**: Handling punctuation (not required here).

### 4. Unique Word Generator from List
- **Approach**: Used a set to track seen words.
- **Challenge**: Case sensitivity handled by converting to lowercase.

### 5. Sublist Generator
- **Approach**: Used slicing to yield sublists of fixed length.
- **Challenge**: Ensuring correct range to avoid index errors.

## How to Run
Each file can be run independently using Python 3. Example:
```bash
python exercise1_fibonacci.py
